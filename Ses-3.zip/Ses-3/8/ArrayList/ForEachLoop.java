import java.util.ArrayList;
import java.util.List;

public class ForEachLoop {

    public static void main(String[] args) {

        int[] list=new int[10];

        for (int i = 0; i < 10; i++)
   			list[i] = i;
        for (int element : list){
            System.out.println(element);


      /*List<String> list = new ArrayList<String>(2);
			list.add("First");
        list.add("Second");*/
        }
    }
}
/*
Advantages of for-each Loop:

    * Less error prone code
    * Improved readability
    * Less number of variables to clean up

Limitations:

    * Cannot be used where the collection is to be altered while traversing/looping
      through
    * May not be suitable while looping through multiple collections in parallel
*/