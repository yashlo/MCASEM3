import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample{

	public static void main(String args[]){

// constructs a new empty ArrayList
		ArrayList arrayList = new ArrayList();

/*To specify initial capacity, use following constructor.
ArrayList ArrayList = new ArrayList(100);

To create ArrayList from Collection use following constructor
ArrayList ArrayList = new ArrayList(Collection collection);
In this case the initial capacity would be 110% of the size of the collection.*/

/*To add value into ArrayList use add() method.
Signature of the add() method is,
boolean add(Object object)
The value would be appended to the list.

To insert value into ArrayList at particular index, use
void add(int index, Object object)
This method will shifts the subsequent elements of the list.

To append all elements of the collection to existing list, use
boolean addAll(Collection c)

To insert all elements of the collection into existing list, use
boolean addAll(int index, Collection collection)

To replace particular element in the ArrayList, use
Object set(int index, Object value)
It returns the previous element present at the specified index.*/

		arrayList.add( new Integer(1) ); // adding value into ArrayList
		arrayList.add( new Integer(2) );
		arrayList.add( new Integer(3) );

/*IMPORTANT : We CAN NOT add primitives to the ArrayList.
We have to wrap it into one of the wrapper before adding.*/

//get number of keys present in the ArrayList
		System.out.println("ArrayList contains " + arrayList.size() + " key value pair.");
/*To check whether ArrayList is empty or not, use isEmpty() method.
isEmpty() returns true is ArrayList is empty, otherwise false.
Finding particular value from the ArrayList :
ArrayList's contains() method returns boolean depending upon the
presense of the value in given ArrayList
Signature of the containsValue method is,
boolean contains(Object value)*/

		if( arrayList.contains( new Integer(1) ) ){

			System.out.println("ArrayList contains 1 as value");
		}else{
		System.out.println("ArrayList does not contain 1 as value");

		}

/*Use get method of ArrayList to get value.Signature of the get method is,
Object get(int index)*/
		Integer one = (Integer) arrayList.get(0);
		System.out.println("Value at 0 index is " + one);
//IMPORTANT:  get method returns Object, so we need to downcast it.

/*To search element within the ArrayList, use
int indexOf(Object element)
it returns the index of first occourance of the specified element.

To find last occourance of the specified element, use
int lastIndexOf(Object element)*/

		System.out.println("Index of first occourance of 1 is " + arrayList.indexOf( new Integer(1) ) );

/*To convert ArrayList to object array, use
Object[] toArray() method.
This method returns an Object array containing all elements of the
ArrayList in the correct order.*/

		System.out.println("Converting ArrayList to Object array");
		Object[] elements = arrayList.toArray();
		for(int i=0; i < elements.length ; i++)
	    	System.out.println(elements[i]);

/*To remove particular element from the ArrayList use,
Object remove(int index)
It returns the element that was removed from the list.

To remove multiple elements from the ArrayList use,
void removeRange(int fromIndex, int toIndex).
It removes elements from the list whose index is between startIndex
(inclusive) and toIndex(Exclusive).

To remove all elements of the ArrayList use,
void clear().
It removes all elements of the ArrayList.*/

		System.out.println("Is 1 removed from the ArrayList ? " + arrayList.remove( 1 ));
	}

}