import java.util.ArrayList;
import java.util.List;

class UglyForLoop {
	public static void main(String[] args) {

	        List list = new ArrayList(2);
	        list.add("First");
	        list.add("Second");
	        String str = null;
	        for(int count = 0; count < list.size(); count++){
	        	str = (String)list.get(count);
                	System.out.println(str);
           	}
        }

   }