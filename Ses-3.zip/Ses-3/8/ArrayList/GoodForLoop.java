import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class GoodForLoop {

   public static void main(String[] args) {
      List list = new ArrayList(2);
      list.add("First");
      list.add("Second");
      String str = null;
      for(Iterator itr = list.iterator(); itr.hasNext();){
          str = (String)itr.next();
          System.out.println(str);
      }
  }

}