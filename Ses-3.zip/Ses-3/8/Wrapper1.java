public class Wrapper1{
	public static void main (String str[]){
/*
		int a = 20;
		Integer i = Integer.valueOf(a);

		Integer j = a;

		System.out.println("i: " + i);
		System.out.println("j: " + j);
		*/

		Integer a = new Integer(3);
		int i = a.intValue();
		int j = a;
		System.out.println("i: " + i);
		System.out.println("j: " + j);
	}
}