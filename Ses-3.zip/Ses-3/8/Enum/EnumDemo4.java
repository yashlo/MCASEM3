/*Two restrictions that apply to enumerations behaving as classes:
1) enums can't inherit other classes
2) enum can't be a superclass / can't be extended

Enumerations inherit Enum:
- Although no superclass can be inherited by enumeration;
all enumerations automatically inherit java.lang.Enum
- This class has three methods:-
	final int ordinal()
	final int compareTo(enumtype e)
	final boolean equals(Object ob)
	- ordinal() : returns the ordinal value of invoking enumeration
	  constant.
	  ordinal value: The position of an enumeration constant in the list
	  of constants is called its ordinal value.
	- compareTo() : is used to compare ordinal value of constant e to
	  that of the invoking constant's ordinal value.
	- If the invoking constant has an ordinal value < ordinal value of e,
	  then method returns Negative value.
	- If the invoking constant has an ordinal value = ordinal value of e,
	  then zero is returned;
	- otherwise positive value is returned.
	- equals() : method compared an enumeration constant for equality with
	  any other object. The two objects will be equal only if they both
	  refer to the same constant, within the same enumeration.*/

enum Flowers{
	Rose, Lotus, Lily, Daisy, Sunflower
}

class EnumDemo4{
	public static void main(String args[]){
		Flowers fl, fl1, fl2;

		System.out.println("Flowers and Ordinal values: ");
		for(Flowers f: Flowers.values())
			System.out.println(f+" " + f.ordinal());
		fl=Flowers.Rose;
		fl1=Flowers.Daisy;
		fl2=Flowers.Rose;

		if(fl.compareTo(fl1)<0)
			System.out.println(fl+" comes before "+ fl1);
		if(fl.compareTo(fl1)>0)
			System.out.println(fl1+" comes before "+ fl);
		if(fl.compareTo(fl2) == 0)
			System.out.println(fl+" equals "+ fl2);
		if(fl.equals(fl2))
			System.out.println(fl+" equals "+ fl2);
		if(fl == fl2)
			System.out.println(fl+" == "+ fl2);
	}
}

/* Disadvantages:
- can't create new constants at Runtime
- For each enum, entire new class
- can't derive enum classes.

Advantages:
- Enums are type safe
- Methods come inbuit in with enums
- enums can be used as labels*/