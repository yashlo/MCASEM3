/* Introduction to Enumerations:
Enumeration means a list of named constants.
In language like c++, enumerations are simply lists of named integer constants.

In java, enumeration defines a class Type where it can have constructors,
methods and instance variables.

Enumeration constants are implicitly declared public, static final.
Type of these constants is the type of enumeration in which they are declared.
Hence, they are self-typed.
*/
enum Flowers{					//keyword to create an enumeration
	Rose, Lotus, Lily, Daisy, Sunflower	//syntax of declaring an enum
}
//Rose, Lotus are Enumeration constants
class EnumDemo1{
	public static void main(String args[]){
		//Declaring a variable for Enum
		Flowers fl;
		//Assigning or instantiating fl (no need of new)
		fl=Flowers.Daisy;
		System.out.println("Value of fl=" + fl);
		//switch can be controlled using enum variable
		switch(fl){
		case Rose: System.out.println("Flower is Rose"); break;
		case Lotus: System.out.println("Flower is Lotus"); break;
		case Lily: System.out.println("Flower is Lily"); break;
		case Daisy: System.out.println("Flower is Daisy"); break;
		case Sunflower: System.out.println("Flower is Sunflower"); break;
		}
	}
}
