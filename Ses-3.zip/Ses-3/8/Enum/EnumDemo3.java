/*Java Enumerations are Class Types:
- Each enumeration constant is an object of its enumeration type.
If enums behave as classes, they can have constructors, methods and
instance variables.
- Each enumeration constant has its own copy of any instance variable
defined by the enumeration.
- When you define a constructor for an enum, it is called when each
enumeration constant is created.
- Arguments to the constructor are specified by putting them inside parenthesis
after each constant.
- Default constructors can also be used in case any enumeration constant
is assigned nothing.*/

enum Flowers{
	Rose(100), Lotus(200), Lily(50), Daisy(70), Sunflower(150), Marigold;
	private int price;
	Flowers(int p){
		price = p;
	}
	Flowers(){
		price=0;
	}
	int getPrice(){
		return price;
	}
}

class EnumDemo3{
	public static void main(String args[]){
		//syntax of calling a method i.e. member of enum
		//Enumname.Constname.method()
		System.out.println("Roses costs "+ Flowers.Rose.getPrice());
		System.out.println("All flower Prices: ");
		for(Flowers f: Flowers.values())
			System.out.println(f+" costs " + f.getPrice());
	}
}
