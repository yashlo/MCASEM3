/*values() and ValueOf() methods:
All enumerations automatically contain two predefined methods - values() and valueOf().
public static enumtype[] values(){ }
public static enumtype ValueOf(String str){ }
Values() - returns an array that contains a list of all the enumeration constants.
valueOf(String s) - returns the enumeration constant whose ordinal value
corresponds to the string passed in s.
Java makes it much easier to translate between the human readable form
of an enumeration constant and its binary value.
This is the advantage of Java�s approach to enumerations.
*/
enum Flowers{
	Rose, Lotus, Lily, Daisy, Sunflower
}

class EnumDemo2{
	public static void main(String args[]){

		Flowers fl;
		System.out.println("All flower constants are:");
		Flowers[] f1 = Flowers.values();
		for(Flowers f: f1)
		//for(Flowers f: Flowers.values())
			System.out.println(f);
		fl=Flowers.valueOf("Rose");
		System.out.println("Fl contains "+fl);
	}
}
