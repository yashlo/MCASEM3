class TestObjectMethods{
	public static void main(String args[]){
		String s = "Ok";
		StringBuffer sb = new StringBuffer(s);
		System.out.println(s.hashCode() + " " + sb.hashCode());

		String t = new String("Ok");
		StringBuffer tb = new StringBuffer(t);
		System.out.println(t.hashCode() + " " + tb.hashCode());
	}
}
/*
Note that the strings s and t have the same hash code because,for
strings, the hash codes are derived from their contents.
The string buffers sb and tb have different hash codes because
no hashCode method has been defined for the StringBuffer class,
and the default hashCode method in the Object class derives the
hash code from the object's memory address.
If you redefine the equals method, you will also need to redefine
the hashCode method for objects that users might insert into a
hash table.
*/