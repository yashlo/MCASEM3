/*
Arranges components either in a row or in a column.
Box class offers a container that uses BoxLayout as its default layout manager.
	BoxLayout(java.awt.Container target, int axis)
axis:
1.BoxLayout.X_AXIS
2.BoxLayout.Y_AXIS
3.BoxLayout.LINE_AXIS
4.BoxLayout.PAGE_AXIS
*/
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class BoxLayoutTest {

  public static void main(String[] args) {
    JFrame frame = new JFrame("BoxLayout Test");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    // top to bottom
    BoxLayout boxLayout = new BoxLayout(frame.getContentPane(), BoxLayout.X_AXIS);
    frame.setLayout(boxLayout);
    frame.add(new JButton("Button 1"));
    frame.add(new JButton("Button 2"));
    frame.add(new JButton("Button 3"));
    frame.pack();
    frame.setVisible(true);
  }
}