import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ScrollBarDemo extends JFrame {
	public static void main(String[] args) {
		(new ScrollBarDemo()).setVisible(true);
	}
	ScrollBarDemo() {
		super("Scroll Bar Demo");
		setSize(350, 250);
		Container cont = getContentPane();
		JScrollBar sbar = new JScrollBar(JScrollBar.HORIZONTAL);
		cont.add(sbar, BorderLayout.NORTH);
		BarListener listener = new BarListener();
		sbar.addAdjustmentListener(listener);
	}

	class BarListener implements AdjustmentListener {
		public void adjustmentValueChanged(AdjustmentEvent e) {
			System.out.println("Val = " + e.getValue());
		}
	}
}