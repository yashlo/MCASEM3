/*
GridBagLayout()

Constraints : (GridBagConstraints feilds)
- int anchor - specifies the location of a component within a cell.
   Default is GridBagConstraints.CENTER
   GridBagConstraints.CENTER, GridBagConstraints.EAST
   GridBagConstraints.NORTH, GridBagConstraints.SOUTH
   GridBagConstraints.WEST,GridBagConstraints.NORTHEAST etc.
   GridBagConstraints.PAGE_START, GridBagConstraints.PAGE_END etc.
- int fill - Specifies how a component is resized if the component
   is smaller than it cell.
   GridBagConstraints.NONE(Default)
   GridBagConstraints.HORIZONTAL
   GridBagConstraints.VERTICAL
   GridBagConstraints.BOTH
- int gridheight - height of component in terms of cells. Default 1
- int gridwidth - width of component in terms of cells. Default 1
- int gridx - specifies the X coordinate of cell to which component will
  be added
- int gridy - specifies the Y coordinate of cell to which component will
  be added
- int ipadx - specifies extra horizontal space that surrounds a component
   within a cell. Default 0
- int ipady - specifies extra vertical space that surrounds a component
   within a cell. Default 0
- double weightx - horizontal spacing between cells
- double weighty - vertical spacing between cells
*/
import java.awt.*;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class GridBagLayoutDemo {

    public GridBagLayoutDemo() {

      JFrame frame = new JFrame("GridBagLayout Source Demo");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      Container pane = frame.getContentPane();

      pane.setBackground(Color.darkGray);
      pane.setSize(300,300);
      GridBagLayout layout = new GridBagLayout();

      pane.setLayout(layout);
      GridBagConstraints gbc = new GridBagConstraints();

      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.gridx = 0;
      gbc.gridy = 0;
      pane.add(new JButton("Button 1"),gbc);

      gbc.gridx = 1;
      gbc.gridy = 0;
      pane.add(new JButton("Button 2"),gbc);

      gbc.fill = GridBagConstraints.VERTICAL;
      gbc.ipady = 20;
      gbc.gridx = 0;
      gbc.gridy = 1;
      pane.add(new JButton("Button 3"),gbc);

      gbc.gridx = 1;
      gbc.gridy = 1;
      pane.add(new JButton("Button 4"),gbc);

      gbc.gridx = 0;
      gbc.gridy = 2;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.gridwidth = 2;
      pane.add(new JButton("Button 5"),gbc);
	  frame.pack();		//it packs the components closely together
      frame.setVisible(true);
    }
    public static void main(String[] args) {
    	new   GridBagLayoutDemo();
    }
}