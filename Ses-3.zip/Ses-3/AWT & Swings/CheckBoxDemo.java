import java.awt.*;
import javax.swing.*;
public class CheckBoxDemo {
public static void main(String[] args) {
JFrame frame = new JFrame("CheckBox Demo");
frame.setSize(350, 250);
Container cont = frame.getContentPane();
cont.setLayout(new FlowLayout());
cont.add(new JCheckBox("Charge my acct"));
cont.add(new JCheckBox("Gift wrap"));
cont.add(new JButton("Submit"));
frame.setVisible(true);
}
}