import java.awt.FlowLayout;
import javax.swing.JApplet;
import javax.swing.JTextField;
/*
<applet code="JTextFieldTooltipExample" width=200 height=200>
</applet>
*/
public class JTextFieldTooltipExample extends JApplet{
     public void init(){
                this.getContentPane().setLayout(new FlowLayout());
                JTextField field = new JTextField("JTextField ToolTip Example",20);
		//void setToolTipText(String toolTip)

			field.setToolTipText("This is JTextField's ToolTip");
     		//String getToolTipText()
                String toolTip = field.getToolTipText();
                System.out.println(toolTip);
                add(field);
        }
}
