/*// Inner class demo.
import java.applet.*;
import java.awt.event.*;
public class InnerClassDemo extends Applet {
	public void init() {
	addMouseListener(new MyMouseAdapter());
}
class MyMouseAdapter extends MouseAdapter {
	public void mousePressed(MouseEvent me) {
	showStatus("Mouse Pressed");
	}
    }
}*/
// Anonymous inner class demo.
import java.applet.*;
import java.awt.event.*;
/*
<applet code="AnonymousInnerClassDemo" width=200 height=100>
</applet>
*/
public class AnonymousInnerClassDemo extends Applet {
	public void init() {
		addMouseListener(new MouseAdapter() {
		public void mousePressed(MouseEvent me) {
			showStatus("Mouse Pressed");
		}	});
	}
}