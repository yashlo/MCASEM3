 import java.awt.*;
 import javax.swing.*;

 public class MenuDemo {

 public static void main(String[] args) {
	 JFrame frame = new JFrame("Menu");

	 JMenuBar mbar = new JMenuBar(); // Create menu bar

	 JMenu fileMenu = new JMenu("File"); // Create file menu
	 fileMenu.add(new JMenuItem("New"));
	 fileMenu.add(new JMenuItem("Exit"));
	 mbar.add(fileMenu);

	 JMenu sampleMenu = new JMenu("Sample"); // Create sample menu
	 sampleMenu.add(new JMenuItem("Plain"));
	 sampleMenu.insertSeparator(1);
	 sampleMenu.add(new JCheckBoxMenuItem("Check"));
	 ButtonGroup group = new ButtonGroup();
	 JRadioButtonMenuItem radioMI;
	 for (int i=0; i<2; i++) {
		 radioMI = new JRadioButtonMenuItem("Radio" + i);
		 group.add(radioMI);

		 sampleMenu.add(radioMI);
	 }
	 JMenu subMenu = new JMenu("SubOptions");
	 subMenu.add(new JMenuItem("AAA"));
	 subMenu.add(new JMenuItem("BBB"));
	 subMenu.add(new JMenuItem("CCC"));
	 sampleMenu.add(subMenu);
	 mbar.add(sampleMenu);

	 frame.setJMenuBar(mbar); // Install menu bar
	 frame.setSize(350, 250);
	 frame.setVisible(true);
	 }
 }