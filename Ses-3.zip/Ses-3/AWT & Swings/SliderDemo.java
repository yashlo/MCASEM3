import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class SliderDemo extends JFrame implements ActionListener{
	JSlider slider;
	SliderDemo()	{

		super("Using slider ...");
		setBounds(160,120,400,200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//new JSlider(int orientation, int min,int max, int value)
		slider = new JSlider(JSlider.VERTICAL,0,50,5);
		//Determines whether tick marks are painted on the slider.
		slider.setPaintTicks(true);
		//Determines whether labels are painted on the slider.
		slider.setPaintLabels(true );
		//Specifying true makes the knob resolve to the closest tick
	    //mark next to where the user positioned the knob.
		slider.setSnapToTicks(false);
		//sets the major tick spacing.
		slider.setMajorTickSpacing(10);
		//sets the minor tick spacing.
		slider.setMinorTickSpacing(5);

		getContentPane().add(slider,BorderLayout.CENTER);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e)	{}
	public static void main(String args[])	{
		new SliderDemo();
	}
}
