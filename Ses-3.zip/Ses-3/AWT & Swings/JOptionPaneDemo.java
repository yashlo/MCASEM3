/*
The class JOptionPane is a component which provides standard methods to pop up a standard dialog box
*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JOptionPaneDemo extends JFrame{

   private JFrame mainFrame;
   private JLabel statusLabel;
   private JPanel controlPanel;

   public JOptionPaneDemo(){
      mainFrame = new JFrame("Java Swing Examples");
      mainFrame.setSize(400,400);
      mainFrame.setLayout(new GridLayout(2, 1));
      mainFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
      statusLabel = new JLabel("",JLabel.CENTER);

      statusLabel.setSize(350,100);

      controlPanel = new JPanel();
      controlPanel.setLayout(new FlowLayout());

      mainFrame.add(controlPanel);
      mainFrame.add(statusLabel);
      mainFrame.setVisible(true);


      JButton okButton = new JButton("OK");
      JButton javaButton = new JButton("Yes/No");
      JButton cancelButton = new JButton("Yes/No/Cancel");

      okButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            //static void showMessageDialog(Component parentComponent, Object message)
            JOptionPane.showMessageDialog(
            mainFrame, "Ok Selected");
         }
      });

      javaButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
			 //static int showConfirmDialog(Component parentComponent, Object message, String title, int optionType)
            int output = JOptionPane.showConfirmDialog(mainFrame
               , "Click any button"
               ,"YES NO Option"
               ,JOptionPane.YES_NO_OPTION);

            if(output == JOptionPane.YES_OPTION){
               statusLabel.setText("Yes selected.");
            }else if(output == JOptionPane.NO_OPTION){
               statusLabel.setText("No selected.");
            }
         }
      });

      cancelButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            int output = JOptionPane.showConfirmDialog(mainFrame
               , "Click any button"
               ,"YES NO CANCEL Option"
               ,JOptionPane.YES_NO_CANCEL_OPTION);

            if(output == JOptionPane.YES_OPTION){
               statusLabel.setText("Yes selected.");
            }else if(output == JOptionPane.NO_OPTION){
               statusLabel.setText("No selected.");
            }else if(output == JOptionPane.CANCEL_OPTION){
               statusLabel.setText("Cancel selected.");
            }
         }
      });

      controlPanel.add(okButton);
      controlPanel.add(javaButton);
      controlPanel.add(cancelButton);
      mainFrame.setVisible(true);
   }

   public static void main(String[] args){
      new JOptionPaneDemo();
     }
}